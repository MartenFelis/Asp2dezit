﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Company.Models
{
    public class CompanyListViewModel
    {
        public List<CompanyDetailViewModel> Books { get; set; }
        public DateTime GeneratedAt => DateTime.Now;
    }
}

﻿using System;
using Company.Entities;


namespace Company.Models
{
    public class CompanyDetailViewModel
    {
        public string Name { get; set; }
        public string Adress { get; set; }
        public int Id { get; set; }
        public string Departement { get; set; }
    }
}

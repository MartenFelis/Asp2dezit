﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Company.Entities
{
    public class Employee
    {
        public int EmployeekId { get; set; }
        public string Name { get; set; }
        public string Firstname { get; set; }
        public bool Gender { get; set; }
        public DateTime Birthday { get; set; }
        public string Workfunction { get; set; }
        public int CompanyId { get; set; }
    }
}
﻿namespace Company.Entities
{
    public class AuthorBook
    {
        public int BookId { get; set; }
        public string Name { get; set; }
        public string Firstname { get; set; }
        public int CompanyId { get; set; }
    }
}
﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace Company.Entities
{
    public class Company
    {
        public string Name { get; set; }
        public string Adress { get; set; }
        public int Id { get; set; }
        public string Departement { get; set; }
    }
}
